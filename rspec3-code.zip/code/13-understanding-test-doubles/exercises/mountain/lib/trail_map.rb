#---
# Excerpted from "Effective Testing with RSpec 3",
# published by The Pragmatic Bookshelf.
# Copyrights apply to this code. It may not be used to create training material,
# courses, books, articles, and the like. Contact us if you are in doubt.
# We make no guarantees that this code is fit for any purpose.
# Visit http://www.pragmaticprogrammer.com/titles/rspec3 for more book information.
#---
puts 'Loading our database query library...'
sleep(1)

module Mountain
  class TrailMap
    def difficulty_of(trail_name)
      # Look up the trail in the database
    end
  end
end
